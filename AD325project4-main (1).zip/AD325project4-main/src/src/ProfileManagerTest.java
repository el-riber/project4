package src;

import org.junit.Before;
import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import static org.junit.Assert.*;

public class ProfileManagerTest {

    private ProfileManager profileManager;
    private Profile profile1;
    private Profile profile2;

    /**
     * Method to set yp tests
     */
    @Before
    public void setUp() {
        profileManager = new ProfileManager();
        profile1 = new Profile("Alice", null, "Happy");
        profile2 = new Profile("Bob", null, "Excited");
        Profile profile3 = new Profile("Charlie", null, "Content");

        profileManager.addProfile(profile1);
        profileManager.addProfile(profile2);
        profileManager.addProfile(profile3);
    }

    /**
     * Method to test adding a profile
     */
    @Test
    public void testAddProfile() {
        // The setUp method has already added three profiles.
        assertEquals(3, profileManager.getProfilesCount());

        // Now let's add another profile and test again.
        Profile profile4 = new Profile("Dave", null, "Thinking");
        profileManager.addProfile(profile4);
        assertEquals(4, profileManager.getProfilesCount());
    }

    /**
     * Method to test removing a profile
     */
    @Test
    public void testRemoveProfile() {
        assertTrue(profileManager.removeProfile("Alice"));
        assertEquals(2, profileManager.getProfilesCount());
        assertNull(profileManager.getProfile("Alice"));
    }

    /**
     * Method to test adding a friend
     */

    @Test
    public void testAddFriendship() {
        profileManager.addFriendship("Alice", "Bob");
        assertTrue(profile1.getFriendProfiles().contains(profile2));
        assertTrue(profile2.getFriendProfiles().contains(profile1));
    }

    /**
     * Method to test removing a friend
     */
    @Test
    public void testRemoveFriendship() {
        profileManager.addFriendship("Alice", "Bob");
        profileManager.removeFriendship("Alice", "Bob");
        assertFalse(profile1.getFriendProfiles().contains(profile2));
        assertFalse(profile2.getFriendProfiles().contains(profile1));
    }

    /**
     * Method to test updating a status
     */
    @Test
    public void testUpdateStatus() {
        profileManager.updateStatus("Alice", "Excited");
        assertEquals("Excited", profile1.getStatus());
    }

    /**
     * Method to test displaying friends
     */
    @Test
    public void testDisplayFriendsOfFriends() {
        // Set up friendships
        profileManager.addFriendship("Alice", "Bob");
        profileManager.addFriendship("Bob", "Charlie");

        // Capture the standard output to test the display method
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        profileManager.displayFriendsOfFriends("Alice");

        // Check that Charlie is listed as a friend of a friend
        String expectedOutput = "Charlie";
        assertTrue(outContent.toString().contains(expectedOutput));
    }
}
