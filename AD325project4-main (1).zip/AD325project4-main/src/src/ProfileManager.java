package src;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class ProfileManager {
    private final Map<String, Profile> profiles;
    private final Map<Profile, Set<Profile>> network;

    public ProfileManager() {
        profiles = new HashMap<>();
        network = new HashMap<>();
    }


    /**
     * Method to add a profile to the network
     * @param profile The profile to be added
     */
    public void addProfile(Profile profile) {
        profiles.put(profile.getName(), profile);
        network.put(profile, new HashSet<>());
    }



    /**
     * Method to remove a profile from the network
     * @param profileName Name of profile to be removed from network
     * @return
     */
    public boolean removeProfile(String profileName) {
        Profile profile = profiles.get(profileName);
        if (profile != null) {
            // Remove this profile from the list of friends of all other profiles
            for (Profile friend : network.get(profile)) {
                network.get(friend).remove(profile);
            }
            // Remove the profile from the network
            network.remove(profile);
            profiles.remove(profileName);
            return true;
        }
        return false;
    }



    /**
     * Method to add a friendship between 2 profiles
     * @param profileName1 Name of 1 of the profiles that will be friended
     * @param profileName2 Name of the other profile that will be friended
     * @return
     */
    public boolean addFriendship(String profileName1, String profileName2) {
        Profile profile1 = profiles.get(profileName1);
        Profile profile2 = profiles.get(profileName2);
        if (profile1 != null && profile2 != null) {
            network.get(profile1).add(profile2);
            network.get(profile2).add(profile1);
            profile1.addFriend(profile2);
            profile2.addFriend(profile1);
            return true;
        }
        return false;
    }



    /**
     * Method to remove friendship between 2 profiles
     * @param profileName1 Name of 1 of the profiles that will remove friendship
     * @param profileName2 Name of the other profile that will remove friendship
     * @return
     */
    public boolean removeFriendship(String profileName1, String profileName2) {
        Profile profile1 = profiles.get(profileName1);
        Profile profile2 = profiles.get(profileName2);
        if (profile1 != null && profile2 != null) {
            network.get(profile1).remove(profile2);
            network.get(profile2).remove(profile1);
            profile1.removeFriend(profile2);
            profile2.removeFriend(profile1);
            return true;
        }
        return false;
    }

    // Method to display all profiles in the network

    /**
     * Method to delete all profiles from the network
     */
    public void displayAllProfiles() {
        for (Profile profile : profiles.values()) {
            profile.printProfileDetails();
        }
    }



    /**
     * Method to access a profile from the network
     * @param profileName Name of the profile you want to access
     * @return
     */
    public Profile getProfile(String profileName) {
        return profiles.get(profileName);
    }


    /**
     * Method to display a friends profile
     * @param profileName Name of the profile you want to display
     */
    public void displayFriends(String profileName) {
        Profile profile = profiles.get(profileName);
        if (profile != null) {
            System.out.println(profileName + "'s friends:");
            for (Profile friend : network.get(profile)) {
                System.out.println(friend.getName());
            }
        } else {
            System.out.println("Profile not found.");
        }
    }


    /**
     * Method to updaye a profile's status
     * @param profileName name of profile you want to updaye
     * @param newStatus what status you want to update to
     * @return
     */
    public boolean updateStatus(String profileName, String newStatus) {
        Profile profile = profiles.get(profileName);
        if (profile != null) {
            profile.setStatus(newStatus);
            return true;
        }
        return false;
    }

    /**
     * Method to display the friends of a particular profile
     * @param profileName Name of the profile whose friends will be displayed
     */
    public void displayFriendsOfFriends(String profileName) {
        Profile profile = profiles.get(profileName);
        if (profile != null) {
            Set<Profile> friendsOfFriends = new HashSet<>();
            for (Profile friend : network.get(profile)) {
                friendsOfFriends.addAll(network.get(friend));
            }
            // Remove the original profile and its direct friends from the set
            friendsOfFriends.remove(profile);
            friendsOfFriends.removeAll(network.get(profile));

            System.out.println(profileName + "'s friends of friends:");
            for (Profile friendOfFriend : friendsOfFriends) {
                System.out.println(friendOfFriend.getName());
            }
        } else {
            System.out.println("Profile not found.");
        }
    }

    /**
     * Method to get the count of profiles in the network
     * @return
     */
    public int getProfilesCount() {
        return profiles.size();
    }

}
