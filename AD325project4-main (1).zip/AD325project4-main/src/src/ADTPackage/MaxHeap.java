package src.ADTPackage;

public class MaxHeap<T extends Comparable<? super T>> implements MaxHeapInterface<T> {
    private T[] heap; // Array of heap entries
    private int lastIndex; // Index of last entry
    private static final int DEFAULT_INITIAL_CAPACITY = 25;

    public MaxHeap() {
        this(DEFAULT_INITIAL_CAPACITY); // Call next constructor
    }

    public MaxHeap(int initialCapacity) {
        @SuppressWarnings("unchecked")
        T[] tempHeap = (T[]) new Comparable[initialCapacity + 1];
        heap = tempHeap;
        lastIndex = 0;
    }

    @Override
    public void add(T newEntry) {
        lastIndex++;
        ensureCapacity();
        heap[lastIndex] = newEntry;
        int newIndex = lastIndex;
        int parentIndex = newIndex / 2;
        while ((parentIndex > 0) && newEntry.compareTo(heap[parentIndex]) > 0) {
            heap[newIndex] = heap[parentIndex];
            newIndex = parentIndex;
            parentIndex = newIndex / 2;
        }
        heap[newIndex] = newEntry;
    }

    @Override
    public T removeMax() {
        T root = null;
        if (!isEmpty()) {
            root = heap[1];
            heap[1] = heap[lastIndex];
            lastIndex--;
            reheap(1);
        }
        return root;
    }

    @Override
    public T getMax() {
        return isEmpty() ? null : heap[1];
    }

    @Override
    public boolean isEmpty() {
        return lastIndex == 0;
    }

    @Override
    public int getSize() {
        return lastIndex;
    }

    @Override
    public void clear() {
        lastIndex = 0;
    }

    private void ensureCapacity() {
        if (lastIndex >= heap.length - 1) { // If array is full, double its size
            @SuppressWarnings("unchecked")
            T[] newHeap = (T[]) new Comparable[heap.length * 2];
            System.arraycopy(heap, 0, newHeap, 0, heap.length);
            heap = newHeap;
        }
    }

    private void reheap(int rootIndex) {
        boolean done = false;
        T orphan = heap[rootIndex];
        int leftChildIndex = 2 * rootIndex;

        while (!done && (leftChildIndex <= lastIndex)) {
            int largerChildIndex = leftChildIndex; // Assume larger
            int rightChildIndex = leftChildIndex + 1;
            if ((rightChildIndex <= lastIndex) && heap[rightChildIndex].compareTo(heap[largerChildIndex]) > 0) {
                largerChildIndex = rightChildIndex;
            }

            if (orphan.compareTo(heap[largerChildIndex]) < 0) {
                heap[rootIndex] = heap[largerChildIndex];
                rootIndex = largerChildIndex;
                leftChildIndex = 2 * rootIndex;
            } else {
                done = true;
            }
        }

        heap[rootIndex] = orphan;
    }
}

