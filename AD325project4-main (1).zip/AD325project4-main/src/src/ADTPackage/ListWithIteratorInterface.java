package src.ADTPackage;

public interface ListWithIteratorInterface<T> extends ListInterface<T>, Iterable<T> {
    /**
     * method to return the iterator
     * @return Iterator
     */
    java.util.Iterator<T> getIterator(); // Correct return type
}


