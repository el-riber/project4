package src.ADTPackage;

public interface PriorityQueueInterface<T extends Comparable<? super T>> {
    /**
     * Add a new item into a priority queue
     * @param newEntry item you want to enter
     */
    void add(T newEntry); // Inserts an item into the priority queue

    /**
     * Removes and returns the item with the highest priority
     * @return item with the highest priority
     */
    T remove(); // Removes and returns the item with the highest priority

    /**
     * Method to retrieve the item with highest priority
     * @return item with the highest priority
     */
    T peek(); // Retrieves the item with the highest priority

    /**
     * Method to check if the priority queue is empty
     * @return boolean value if the priority queue is empty or not
     */
    boolean isEmpty(); // Checks if the priority queue is empty

    /**
     * Method to get the size of the priority queue
     * @return int of the size of the priority queue
     */
    int getSize(); // Gets the number of items in the priority queue

    /**
     * Clears all items in the priority queue
     */
    void clear(); // Removes all items from the priority queue
}

