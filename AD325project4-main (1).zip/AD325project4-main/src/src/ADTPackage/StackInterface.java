package src.ADTPackage;

public interface StackInterface<T> {
    /**
     * Puts a item onto the top of the stack
     * @param newEntry item to be entered
     */
    void push(T newEntry); // Adds a new entry to the top of the stack

    /**
     * Method that removes and returns the top entry of the stack
     * @return the top entry of the stack
     */
    T pop(); // Removes and returns the top entry of the stack

    /**
     * Retrieves the top entry of the stack without removing it
     * @return value of the top of stack
     */
    T peek(); // Retrieves the top entry of the stack without removing it

    /**
     * Method to check if the stack is empty
     * @return boolean value if stack is empty or not
     */
    boolean isEmpty(); // Checks if the stack is empty

    /**
     * Method to clear the whole stack
     */
    void clear(); // Removes all entries from the stack
}

