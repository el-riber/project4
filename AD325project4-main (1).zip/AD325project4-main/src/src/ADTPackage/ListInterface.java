package src.ADTPackage;

public interface ListInterface<T> {
    /**
     * Adds a new entry to the end of the list.
     *
     * @param newEntry The entry to be added to the end of the list.
     */
    void add(T newEntry); // Adds a new entry to the end of the list.
    /**
     * Adds a new entry at a specified position in the list.
     *
     * @param newPosition The position at which the new entry will be added.
     * @param newEntry    The entry to be added to the specified position.
     */
    void add(int newPosition, T newEntry); // Adds a new entry at a specified position.
    /**
     * Removes the entry at the given position from the list.
     *
     * @param givenPosition The position of the entry to be removed.
     * @return The entry that was removed from the list.
     */
    T remove(int givenPosition); // Removes the entry at a given position.
    /**
     * Removes all entries from the list, leaving it empty.
     */
    void clear(); // Removes all entries from the list.
    /**
     * Replaces the entry at the given position with a new entry.
     *
     * @param givenPosition The position of the entry to be replaced.
     * @param newEntry      The new entry to replace the existing entry.
     * @return The entry that was replaced.
     */
    T replace(int givenPosition, T newEntry); // Replaces the entry at a given position with a new entry.
    /**
     * Retrieves the entry at the given position in the list.
     *
     * @param givenPosition The position of the entry to be retrieved.
     * @return The entry at the specified position.
     */
    T getEntry(int givenPosition); // Retrieves the entry at a given position.
    /**
     * Determines whether the list contains a given entry.
     *
     * @param anEntry The entry to be checked for existence in the list.
     * @return true if the list contains the specified entry, false otherwise.
     */
    boolean contains(T anEntry); // Determines whether the list contains a given entry.
    /**
     * Gets the length of the list.
     *
     * @return The number of entries in the list.
     */
    int getLength(); // Gets the length of the list.
    /**
     * Checks whether the list is empty.
     *
     * @return true if the list is empty, false otherwise.
     */
    boolean isEmpty(); // Checks whether the list is empty.
    /**
     * Retrieves all entries in the list in the order they occur.
     *
     * @return An array containing all entries in the list.
     */
    T[] toArray(); // Retrieves all entries that are in this list in the order they occur in the list.
}

