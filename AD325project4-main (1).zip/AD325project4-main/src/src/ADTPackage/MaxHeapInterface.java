package src.ADTPackage;

public interface MaxHeapInterface<T extends Comparable<? super T>> {
    /**
     * Method to add a new entry to the heap
     * @param newEntry New entry to the heap
     */
    void add(T newEntry); // Adds a new entry to the heap

    /**
     * method to remove and return the largest item in the heap
     * @return largest item in the heap
     */
    T removeMax(); // Removes and returns the largest item in the heap

    /**
     * Method to get the largest item in the heap
     * @return the largest item in the heap
     */
    T getMax(); // Retrieves the largest item in the heap

    /**
     * Checks if the heap is empty
     * @return boolean value if heap is empty or not
     */
    boolean isEmpty(); // Checks if the heap is empty

    /**
     * Method to ge the size of the heap
     * @return int of the size of the heap
     */
    int getSize(); // Gets the number of items in the heap

    /**
     * Method to clear the heap
     */
    void clear(); // Removes all entries from the heap
}

