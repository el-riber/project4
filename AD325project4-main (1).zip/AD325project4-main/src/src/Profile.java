package src;
import java.util.ArrayList;
import java.util.List;

// create an Image class or use a library for handling images.
// assume the image is represented by a string (URL or file path).
public class Profile {
    private String name;
    private String image; // optional, can be a URL or file path
    private String status;
    private List<Profile> friendProfiles;

    // Constructor to create a profile with the required attributes.
    // The image is optional, so it can be null.

    /**
     * Constructor method for a profile
     * @param name Name of profile
     * @param image image of the profile
     * @param status Status of profile
     */
    public Profile(String name, String image, String status) {
        this.name = name;
        this.image = image;
        this.status = status;
        this.friendProfiles = new ArrayList<>();
    }

    // Getter and setter for the name.

    /**
     * Method for getter for name of profile
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Method for setter for name of profile
     * @param name
     */

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter for the image.

    /**
     * Getter method for image
     * @return image
     */
    public String getImage() {
        return image;
    }

    /**
     * Setter method for image
     * @param image image
     */
    public void setImage(String image) {
        this.image = image;
    }

    // Getter and setter for the status.

    /**
     * Getter method for status
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Setter method for status
     * @param status status
     */

    public void setStatus(String status) {
        this.status = status;
    }

    // Method to add a friend profile.

    /**
     * Method to add a friend to the profile
     * @param friend Name of the profile you want to make a friend
     */
    public void addFriend(Profile friend) {
        if (!friendProfiles.contains(friend)) {
            friendProfiles.add(friend);
        }
    }



    /**
     * Method to remove a friend profile
     * @param friend Give the profile of the friend to remove
     */
    public void removeFriend(Profile friend) {
        friendProfiles.remove(friend);
    }



    /**
     * Method to get the list of friend profiles
     * @return Returns a list of all of the friends profiles
     */
    public List<Profile> getFriendProfiles() {
        return new ArrayList<>(friendProfiles); // Return a copy to avoid external modification
    }

    /**
     * Method to print all the details of the profile
     */

    public void printProfileDetails() {
        System.out.println("Name: " + name);
        System.out.println("Image: " + (image != null ? image : "No Image"));
        System.out.println("Status: " + status);
        System.out.print("Friends: ");
        if (friendProfiles.isEmpty()) {
            System.out.println("No friends yet.");
        } else {
            for (Profile friend : friendProfiles) {
                System.out.print(friend.getName() + ", ");
            }
            System.out.println();
        }
    }
}
