package src.GraphPackage;

import java.util.*;

public class Vertex<T> implements VertexInterface<T> {
    private T label;
    private List<Edge> edgeList; // Edges to neighbors
    private boolean visited; // True if the vertex has been visited
    private VertexInterface<T> predecessor; // Previous vertex on a path
    private double cost; // Cost to reach this vertex

    public Vertex(T label) {
        this.label = label;
        edgeList = new ArrayList<>();
        visited = false;
        predecessor = null;
        cost = 0;
    }

    @Override
    public T getLabel() {
        return label;
    }

    @Override
    public void visit() {
        visited = true;
    }

    @Override
    public void unvisit() {
        visited = false;
    }

    @Override
    public boolean isVisited() {
        return visited;
    }

    @Override
    public boolean connect(VertexInterface<T> endVertex, double edgeWeight) {
        // Add edge to the list
        return edgeList.add(new Edge(endVertex, edgeWeight));
    }

    @Override
    public boolean connect(VertexInterface<T> endVertex) {
        return connect(endVertex, 0);
    }

    @Override
    public boolean disconnect(VertexInterface<T> endVertex) {
        Iterator<Edge> it = edgeList.iterator();
        while (it.hasNext()) {
            if (it.next().getEndVertex().equals(endVertex)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    @Override
    public Iterator<VertexInterface<T>> getNeighborIterator() {
        return new NeighborIterator();
    }

    @Override
    public Iterator<Double> getWeightIterator() {
        return new WeightIterator();
    }

    @Override
    public boolean hasNeighbor() {
        return !edgeList.isEmpty();
    }

    @Override
    public VertexInterface<T> getUnvisitedNeighbor() {
        for (Edge edge : edgeList) {
            if (!edge.getEndVertex().isVisited()) {
                return edge.getEndVertex();
            }
        }
        return null;
    }

    @Override
    public void setPredecessor(VertexInterface<T> predecessor) {
        this.predecessor = predecessor;
    }

    @Override
    public VertexInterface<T> getPredecessor() {
        return predecessor;
    }

    @Override
    public boolean hasPredecessor() {
        return predecessor != null;
    }

    @Override
    public void setCost(double newCost) {
        cost = newCost;
    }

    @Override
    public double getCost() {
        return cost;
    }

    private class Edge {
        private VertexInterface<T> vertex; // End vertex
        private double weight; // Edge weight

        private Edge(VertexInterface<T> vertex, double weight) {
            this.vertex = vertex;
            this.weight = weight;
        }

        public VertexInterface<T> getEndVertex() {
            return vertex;
        }

        public double getWeight() {
            return weight;
        }
    }

    private class NeighborIterator implements Iterator<VertexInterface<T>> {
        private Iterator<Edge> edges;

        private NeighborIterator() {
            edges = edgeList.iterator();
        }

        public boolean hasNext() {
            return edges.hasNext();
        }

        public VertexInterface<T> next() {
            VertexInterface<T> nextNeighbor = null;
            if (edges.hasNext()) {
                Edge edgeToNextNeighbor = edges.next();
                nextNeighbor = edgeToNextNeighbor.getEndVertex();
            } else {
                throw new NoSuchElementException();
            }
            return nextNeighbor;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private class WeightIterator implements Iterator<Double> {
        private Iterator<Edge> edges;

        private WeightIterator() {
            edges = edgeList.iterator();
        }

        public boolean hasNext() {
            return edges.hasNext();
        }

        public Double next() {
            double weight = 0;
            if (edges.hasNext()) {
                Edge edgeToNext = edges.next();
                weight = edgeToNext.getWeight();
            } else {
                throw new NoSuchElementException();
            }
            return weight;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }
}


