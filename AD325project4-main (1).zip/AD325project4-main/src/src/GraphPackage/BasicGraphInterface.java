package src.GraphPackage;

public interface BasicGraphInterface<T> {
    /**
     * Adds a vertex to the graph
     * @param vertexLabel Vertex to be added
     * @return
     */
    boolean addVertex(T vertexLabel); // Adds a vertex to the graph

    /**
     * Connects two vertices with a edge
     * @param begin starting vertex
     * @param end ending vertex
     * @return returns boolean value for successful run
     */
    boolean connect(T begin, T end); // Connects two vertices with an edge

    /**
     * Method to remove the edge between two vertices
     * @param begin Starting vertex
     * @param end Ending Vertex
     * @return return boolean value for successful deletion
     */
    boolean disconnect(T begin, T end); // Removes the edge between two vertices

    /**
     * Method to check if there is a edge between two vertices
     * @param begin Starting vertex
     * @param end Ending Vertex
     * @return Returns boolean value for successful run
     */
    boolean hasEdge(T begin, T end); // Checks if an edge exists between two vertices

    /**
     * Method to check number of vertices in the graph
     * @return Number of vertices
     */
    int getNumberOfVertices(); // Gets the number of vertices

    /**
     * Method to check number of edges in an array
     * @return Number of edges
     */
    int getNumberOfEdges(); // Gets the number of edges
    void clear(); // Clears the graph
}
