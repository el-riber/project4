package src.GraphPackage;

import java.util.Iterator;

public interface VertexInterface<T> {
    /**
     * Method to return label of vertex
     * @return Label of vertex
     */
    T getLabel(); // Returns the label of the vertex

    /**
     * Method to mark vertex as visited
     */
    void visit(); // Marks the vertex as visited

    /**
     * Method to remove visited mark from a vertex
     */
    void unvisit(); // Removes the visited mark from the vertex

    /**
     * Method to check if a vertex has been visited
     * @return boolean value if vertex has been visited
     */
    boolean isVisited(); // Checks if the vertex has been visited

    /**
     * Method to connect the vertex to another with an edge with weight
     * @param endVertex Ending vertex
     * @param edgeWeight Weight of edge
     * @return boolean value if the vertex has been connected
     */
    boolean connect(VertexInterface<T> endVertex, double edgeWeight); // Connects this vertex to another with an edge with weight

    /**
     * Method to connect the vertex to another with an edge with no weight
     * @param endVertex Ending vertex
     * @return boolean value if the vertex has been connected
     */
    boolean connect(VertexInterface<T> endVertex); // Connects this vertex to another with an unweighted edge

    /**
     * Method to disconnect the vertex with another vertex
     * @param endVertex Vertex to be disconnected from
     * @return boolean value if the vertex has been disconnected
     */
    boolean disconnect(VertexInterface<T> endVertex); // Removes the edge connecting this vertex to another

    /**
     * Gets the neighbors of the vertex
     * @return Iterator of the vertex neighbors
     */
    Iterator<VertexInterface<T>> getNeighborIterator(); // Returns an iterator of this vertex's neighbors

    /**
     * Gets the weight of each edge between each neighbor
     * @return Iterator of each edge weight of neighbor of the vertex
     */
    Iterator<Double> getWeightIterator(); // Returns an iterator of the weights of the edges to each neighbor

    /**
     * Method to check if the vertex has neighbors
     * @return boolean value if there are neighbors for the vertex
     */
    boolean hasNeighbor(); // Checks if the vertex has any neighbors

    /**
     * A method to get a unvisited neighbor, if there are any
     * @return Returns the unvisited neighbor
     */
    VertexInterface<T> getUnvisitedNeighbor(); // Returns an unvisited neighbor, if any

    /**
     * Sets the predessor of the vertex
     * @param predecessor Predecessor of vertex
     */
    void setPredecessor(VertexInterface<T> predecessor); // Sets a predecessor vertex

    /**
     * A method to get the vertex predecessor
     * @return The predecessor of the vertex
     */
    VertexInterface<T> getPredecessor(); // Returns the predecessor vertex

    /**
     * Method to check if there is a predecessor vertex of the vertex
     * @return boolean value if there is a predecessor vertex
     */
    boolean hasPredecessor(); // Checks if the vertex has a predecessor

    /**
     * Sets the cost to reach this vertex
     * @param newCost cost to reach vertex
     */
    void setCost(double newCost); // Sets the cost to reach this vertex

    /**
     * Gets cost to reach this vertex
     * @return The cost to reach this vertex
     */
    double getCost(); // Returns the cost to reach this vertex
}

