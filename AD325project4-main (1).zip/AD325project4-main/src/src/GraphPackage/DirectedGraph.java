package src.GraphPackage;

import java.util.*;

public class DirectedGraph<T> implements GraphInterface<T>, GraphAlgorithmsInterface<T> {
    private Map<T, List<T>> adjacencyList;

    public DirectedGraph() {
        adjacencyList = new HashMap<>();
    }

    /**
     *
     * @param vertexLabel Vertex to be added
     * @return
     */
    @Override
    public boolean addVertex(T vertexLabel) {
        if (!adjacencyList.containsKey(vertexLabel)) {
            adjacencyList.put(vertexLabel, new ArrayList<>());
            return true;
        }
        return false;
    }


    @Override
    public boolean addEdge(T begin, T end, double edgeWeight) {
        return addEdge(begin, end); // In this simple implementation, edge weight is ignored
    }

    @Override
    public boolean addEdge(T begin, T end) {
        if (adjacencyList.containsKey(begin) && adjacencyList.containsKey(end)) {
            adjacencyList.get(begin).add(end);
            return true;
        }
        return false;
    }


    @Override
    public boolean hasEdge(T begin, T end) {
        return adjacencyList.containsKey(begin) && adjacencyList.get(begin).contains(end);
    }

    @Override
    public boolean isEmpty() {
        return adjacencyList.isEmpty();
    }


    @Override
    public int getNumberOfVertices() {
        return adjacencyList.size();
    }


    @Override
    public int getNumberOfEdges() {
        int edgeCount = 0;
        for (T vertex : adjacencyList.keySet()) {
            edgeCount += adjacencyList.get(vertex).size();
        }
        return edgeCount;
    }


    @Override
    public void clear() {
        adjacencyList.clear();
    }


    @Override
    public void depthFirstTraversal(T startVertex) {
        Set<T> visited = new HashSet<>();
        depthFirstTraversalHelper(startVertex, visited);
    }

    /**
     * Method to help perform DFS for the graph
     * @param vertex Vertex where DFS will start from
     * @param visited Set to keep track if a vertex has been visited
     */
    private void depthFirstTraversalHelper(T vertex, Set<T> visited) {
        visited.add(vertex);
        System.out.println(vertex); // Process the current vertex

        for (T adjacent : adjacencyList.get(vertex)) {
            if (!visited.contains(adjacent)) {
                depthFirstTraversalHelper(adjacent, visited);
            }
        }
    }


    @Override
    public void breadthFirstTraversal(T startVertex) {
        Set<T> visited = new HashSet<>();
        Queue<T> queue = new LinkedList<>();

        queue.add(startVertex);
        visited.add(startVertex);

        while (!queue.isEmpty()) {
            T vertex = queue.poll();
            System.out.println(vertex); // Process the current vertex

            for (T adjacent : adjacencyList.get(vertex)) {
                if (!visited.contains(adjacent)) {
                    visited.add(adjacent);
                    queue.add(adjacent);
                }
            }
        }
    }
}


