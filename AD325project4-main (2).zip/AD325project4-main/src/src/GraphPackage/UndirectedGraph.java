package src.GraphPackage;

public class UndirectedGraph<T> extends DirectedGraph<T> {

    @Override
    public boolean addEdge(T begin, T end, double edgeWeight) {
        // Ensure that edges are added in both directions
        boolean addedEdgeFromBeginToEnd = super.addEdge(begin, end, edgeWeight);
        boolean addedEdgeFromEndToBegin = super.addEdge(end, begin, edgeWeight);

        return addedEdgeFromBeginToEnd && addedEdgeFromEndToBegin;
    }

    @Override
    public boolean addEdge(T begin, T end) {
        // Ensure that edges are added in both directions
        boolean addedEdgeFromBeginToEnd = super.addEdge(begin, end);
        boolean addedEdgeFromEndToBegin = super.addEdge(end, begin);

        return addedEdgeFromBeginToEnd && addedEdgeFromEndToBegin;
    }

    //if we  implement a removeEdge method, ensure it's also in the DirectedGraph class
}
