package src.GraphPackage;

public interface GraphInterface<T> {
    /**
     * This method will add a vertex to the directed graph
     * @param vertexLabel Vertex to be added
     * @return boolean value if vertex was added
     */
    boolean addVertex(T vertexLabel); // Adds a vertex to the graph
    boolean addEdge(T begin, T end, double edgeWeight); // Adds a weighted edge between two vertices
    /**
     * Method to add an edge between 2 vertex
     * @param begin Vertex where edge will start
     * @param end Vertex where edge will end
     * @return boolean value for successful run
     */
    boolean addEdge(T begin, T end); // Adds an unweighted edge between two vertices
    /**
     * Method to check if there is an edge between 2 vertex
     * @param begin Name of starting vertex
     * @param end Name of ending vertex
     * @return boolean value if there is a edge or not
     */
    boolean hasEdge(T begin, T end); // Checks if an edge exists between two vertices
    /**
     * Method to check if the graph is empty
     * @return boolean value if graph is empty
     */
    boolean isEmpty(); // Checks if the graph is empty
    /**
     * Method to get the number of vertices in the graph
     * @return Number of vertices
     */
    int getNumberOfVertices(); // Gets the number of vertices in the graph
    /**
     * Method to get the number of edges in the graph
     * @return Number of edges
     */
    int getNumberOfEdges(); // Gets the number of edges in the graph
    /**
     * Method to clear the graph
     */
    void clear(); // Clears the graph
}
