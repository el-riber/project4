package src.GraphPackage;

public interface GraphAlgorithmsInterface<T> {
    /**
     * Method to perform a DFS in the graph
     * @param startVertex Starting vertex of DFS
     */
    void depthFirstTraversal(T startVertex); // Performs depth-first traversal of the graph


    /**
     * Method to perform a BFS of a graph
     * @param startVertex Starting vertex of BFS
     */
    void breadthFirstTraversal(T startVertex); // Performs breadth-first traversal of the graph
    // Other common graph algorithms like Dijkstra's, Prim's, etc. can be added here
}

