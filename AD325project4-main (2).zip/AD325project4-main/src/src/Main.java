package src;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProfileManager profileManager = new ProfileManager();
        String currentUser = null; // To track the current user

        while (true) {
            System.out.println("\nWelcome to the Social Media Network");
            System.out.println("1. Create a profile");
            System.out.println("2. Delete a profile");
            System.out.println("3. Add a friend");
            System.out.println("4. Remove a friend");
            System.out.println("5. Display all profiles");
            System.out.println("6. Display my friends");
            System.out.println("7. Update my status");
            System.out.println("8. Switch the current user");
            System.out.println("9. Logout (end program)");
            System.out.print("Select an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (option) {
                case 1: // Create a profile
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter status: ");
                    String status = scanner.nextLine();
                    Profile profile = new Profile(name, null, status);
                    profileManager.addProfile(profile);
                    if (currentUser == null) {
                        currentUser = name; // Set the first user as the current user
                    }
                    System.out.println("Profile created for " + name);
                    break;

                case 2: // Delete a profile
                    System.out.print("Enter the name of the profile to delete: ");
                    String nameToDelete = scanner.nextLine();
                    if (profileManager.removeProfile(nameToDelete)) {
                        System.out.println("Profile deleted.");
                    } else {
                        System.out.println("Profile not found.");
                    }
                    break;

                case 3: // Add a friend
                    System.out.print("Enter the name of the friend to add: ");
                    String friendName = scanner.nextLine();
                    if (profileManager.addFriendship(currentUser, friendName)) {
                        System.out.println("Friend added.");
                    } else {
                        System.out.println("Could not add friend. Make sure both profiles exist.");
                    }
                    break;

                case 4: // Remove a friend
                    System.out.print("Enter the name of the friend to remove: ");
                    String friendToRemove = scanner.nextLine();
                    if (profileManager.removeFriendship(currentUser, friendToRemove)) {
                        System.out.println("Friend removed.");
                    } else {
                        System.out.println("Could not remove friend.");
                    }
                    break;

                case 5: // Display all profiles
                    profileManager.displayAllProfiles();
                    break;

                case 6: // Display my friends
                    if (currentUser != null) {
                        profileManager.displayFriends(currentUser);
                    } else {
                        System.out.println("No user is currently logged in.");
                    }
                    break;

                case 7: // Update my status
                    if (currentUser != null) {
                        System.out.print("Enter your new status: ");
                        String newStatus = scanner.nextLine();
                        profileManager.getProfile(currentUser).setStatus(newStatus);
                        System.out.println("Status updated.");
                    } else {
                        System.out.println("No user is currently logged in.");
                    }
                    break;

                case 8: // Switch the current user
                    System.out.print("Enter the name of the user to switch to: ");
                    String userToSwitchTo = scanner.nextLine();
                    if (profileManager.getProfile(userToSwitchTo) != null) {
                        currentUser = userToSwitchTo;
                        System.out.println("Switched to " + currentUser);
                    } else {
                        System.out.println("Profile not found.");
                    }
                    break;

                case 9: // Logout (end program)
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }
}

