package src.ADTPackage;
public interface DictionaryInterface<K, V> {
    /**
     * Method to add a new value into the dictionary as a key-value pair
     * @param key key data
     * @param value value data
     * @return null if the key is succesful, or the value if the key is preexisting
     */
    V add(K key, V value); // Add a new entry to the dictionary. Returns null if the addition is successful, or the value of the existing key if it is replaced.
    /**
     * Removes the entry for the specified key from the dictionary.
     *
     * @param key The key of the entry to be removed.
     * @return The value that was associated with the key, or null if the key did not exist.
     */
    V remove(K key); // Remove the entry for the key. Returns the value that was associated with the key, or null if the key did not exist.
    /**
     * Retrieves the value associated with the specified key.
     *
     * @param key The key whose associated value is to be retrieved.
     * @return The value associated with the key, or null if the key is not found in the dictionary.
     */
    V getValue(K key); // Retrieve the value associated with the key.

    /**
     * Checks if the dictionary contains an entry for the specified key.
     *
     * @param key The key to be checked for existence in the dictionary.
     * @return true if the dictionary contains an entry for the key, false otherwise.
     */
    boolean contains(K key); // Check if the dictionary contains an entry for the key.
    /**
     * Checks if the dictionary is empty.
     *
     * @return true if the dictionary is empty, false otherwise.
     */
    boolean isEmpty(); // Check if the dictionary is empty.
    /**
     * Gets the number of entries in the dictionary.
     *
     * @return The number of entries in the dictionary.
     */
    int getSize(); // Get the number of entries in the dictionary.
    /**
     * Removes all entries from the dictionary, leaving it empty.
     */
    void clear(); // Remove all entries from the dictionary.
}
