package src.ADTPackage;

public interface QueueInterface<T> {
    /**
     * Method to add a new entry to back of queue
     * @param newEntry New entry into queue
     */
    void enqueue(T newEntry); // Adds a new entry to the back of the queue

    /**
     * Removes the first entry that entered the queue
     * @return
     */
    T dequeue(); // Removes and returns the front entry of the queue

    /**
     * Method to get the front of the queue without removing it
     * @return Return the front of the queue
     */
    T getFront(); // Retrieves the front entry of the queue without removing it

    /**
     * Method to check if the queue is empty
     * @return Boolean value checking to see if queue is empty
     */
    boolean isEmpty(); // Checks if the queue is empty

    /**
     * Method to remove all entries from the queue
     */
    void clear(); // Removes all entries from the queue
}

