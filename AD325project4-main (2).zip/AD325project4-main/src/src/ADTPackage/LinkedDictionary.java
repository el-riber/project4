package src.ADTPackage;

public class LinkedDictionary<K, V> implements DictionaryInterface<K, V> {
    private Node<K, V> firstNode;
    private int numberOfEntries;

    public LinkedDictionary() {
        firstNode = null;
        numberOfEntries = 0;
    }

    @Override
    public V add(K key, V value) {
        Node<K, V> currentNode = findNode(key);
        if (currentNode != null) {
            V oldValue = currentNode.getValue();
            currentNode.setValue(value);
            return oldValue;
        } else {
            Node<K, V> newNode = new Node<>(key, value);
            newNode.setNextNode(firstNode);
            firstNode = newNode;
            numberOfEntries++;
            return null;
        }
    }

    @Override
    public V remove(K key) {
        Node<K, V> currentNode = firstNode;
        Node<K, V> nodeBefore = null;

        while (currentNode != null && !key.equals(currentNode.getKey())) {
            nodeBefore = currentNode;
            currentNode = currentNode.getNextNode();
        }

        if (currentNode != null) {
            V value = currentNode.getValue();
            if (nodeBefore == null) {
                firstNode = currentNode.getNextNode();
            } else {
                nodeBefore.setNextNode(currentNode.getNextNode());
            }
            numberOfEntries--;
            return value;
        }

        return null;
    }

    @Override
    public V getValue(K key) {
        Node<K, V> currentNode = findNode(key);
        return (currentNode == null) ? null : currentNode.getValue();
    }

    @Override
    public boolean contains(K key) {
        return findNode(key) != null;
    }

    @Override
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }

    @Override
    public int getSize() {
        return numberOfEntries;
    }

    @Override
    public void clear() {
        firstNode = null;
        numberOfEntries = 0;
    }

    private Node<K, V> findNode(K key) {
        Node<K, V> currentNode = firstNode;
        while (currentNode != null && !key.equals(currentNode.getKey())) {
            currentNode = currentNode.getNextNode();
        }
        return currentNode;
    }

    private class Node<K, V> {
        private K key;
        private V value;
        private Node<K, V> next;

        private Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }

        private K getKey() {
            return key;
        }

        private V getValue() {
            return value;
        }

        private void setValue(V value) {
            this.value = value;
        }

        private Node<K, V> getNextNode() {
            return next;
        }

        private void setNextNode(Node<K, V> next) {
            this.next = next;
        }
    }
}
