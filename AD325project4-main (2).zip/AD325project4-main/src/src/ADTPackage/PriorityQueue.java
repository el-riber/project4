package src.ADTPackage;

public class PriorityQueue<T extends Comparable<? super T>> {
    private T[] heap; // Array of heap entries
    private int lastIndex; // Index of last entry
    private static final int DEFAULT_INITIAL_CAPACITY = 10;

    public PriorityQueue() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    public PriorityQueue(int initialCapacity) {
        @SuppressWarnings("unchecked")
        T[] tempHeap = (T[]) new Comparable[initialCapacity + 1];
        heap = tempHeap;
        lastIndex = 0;
    }

    public void add(T newEntry) {
        int newIndex = lastIndex + 1;
        int parentIndex = newIndex / 2;
        while ((parentIndex > 0) && newEntry.compareTo(heap[parentIndex]) > 0) {
            heap[newIndex] = heap[parentIndex];
            newIndex = parentIndex;
            parentIndex = newIndex / 2;
        }
        heap[newIndex] = newEntry;
        lastIndex++;
        ensureCapacity();
    }

    public T remove() {
        T root = null;
        if (!isEmpty()) {
            root = heap[1];
            heap[1] = heap[lastIndex];
            lastIndex--;
            reheap(1);
        }
        return root;
    }

    public T peek() {
        return isEmpty() ? null : heap[1];
    }

    public boolean isEmpty() {
        return lastIndex == 0;
    }

    public int getSize() {
        return lastIndex;
    }

    public void clear() {
        lastIndex = 0;
    }

    private void ensureCapacity() {
        if (lastIndex >= heap.length - 1) {
            @SuppressWarnings("unchecked")
            T[] newHeap = (T[]) new Comparable[heap.length * 2];
            System.arraycopy(heap, 0, newHeap, 0, heap.length);
            heap = newHeap;
        }
    }

    private void reheap(int rootIndex) {
        boolean done = false;
        T orphan = heap[rootIndex];
        int leftChildIndex = 2 * rootIndex;

        while (!done && (leftChildIndex <= lastIndex)) {
            int largerChildIndex = leftChildIndex; // Assume larger
            int rightChildIndex = leftChildIndex + 1;

            if ((rightChildIndex <= lastIndex) && heap[rightChildIndex].compareTo(heap[largerChildIndex]) > 0) {
                largerChildIndex = rightChildIndex;
            }

            if (orphan.compareTo(heap[largerChildIndex]) < 0) {
                heap[rootIndex] = heap[largerChildIndex];
                rootIndex = largerChildIndex;
                leftChildIndex = 2 * rootIndex;
            } else {
                done = true;
            }
        }

        heap[rootIndex] = orphan;
    }
}
